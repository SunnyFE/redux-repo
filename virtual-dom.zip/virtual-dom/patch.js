
//把虚拟dom的变更更新到真实的domNode上
var patch = require("./vdom/patch.js")

module.exports = patch
