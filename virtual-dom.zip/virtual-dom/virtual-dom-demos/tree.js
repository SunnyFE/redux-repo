var h = require('../h');
var diff = require('../diff');
var patch = require('../patch');
var createElement = require('../create-element');

// 1: Create a function that declares what the DOM should look like
function render(count) {
    return h('div', {
        style: {
            textAlign: 'center',
            lineHeight: (100 + count) + 'px',
            border: '1px solid red',
            width: (100 + count) + 'px',
            height: (100 + count) + 'px'
        },
        'data-level':'0',
    }, [
            h('div', {
                'data-level':'1',
                'data-id': 'div'
            }, [h('span', {
                'data-level':'2',
                'data-id': 'span',
                'data-count': count + 1
            }), h('ul', {
                'data-level':'2',
                'data-id': 'span',
                'data-count': count + 1
            }),
                ]),
            h('div', {
                'data-level':'1',
                'data-id': 'div',
                'data-count': count
            }, [h('span', {
                'data-level':'2',
                'data-id': 'span',
                'data-count': count + 1
            }), h('ul', {
                'data-level':'2',
                'data-id': 'span',
                'data-count': count + 1
            }),
                ])


        ]);
}

// 2: Initialise the document
var count = 0;      // We need some app data. Here we just store a count.

var tree = render(count);               // We need an initial tree
var rootNode = createElement(tree);     // Create an initial root DOM node ...
var document = require("global/document")
document.body.appendChild(rootNode);    // ... and it should be in the document

// 3: Wire up the update logic
setInterval(function () {
    count++;

    var newTree = render(count);
    var patches = diff(tree, newTree);
    rootNode = patch(rootNode, patches);    
    tree = newTree;
}, 1000);