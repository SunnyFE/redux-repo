// 计算两个虚拟dom 的差别
var diff = require("./vtree/diff.js")

module.exports = diff
